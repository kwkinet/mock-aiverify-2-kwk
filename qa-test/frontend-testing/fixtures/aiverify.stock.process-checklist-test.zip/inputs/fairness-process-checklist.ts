import { getTotal, getCompleted } from './processChecklistSummary' 
import { config } from './config-fairness';

/**
 * Return summary of data
 */
export function summary(data: any): string {
	if (!data)
		return "No data";
  return `${getCompleted(data)} out of ${getTotal(config)} Checks done`
}

/**
 * Return progress in percentage (0-100)
 */
export function progress(data: any): number {
	if (!data)
		return 0;
  return Math.round(getCompleted(data)/getTotal(config)*100)
}

/**
 * Validate data
 */
export function validate(data: any): boolean {
  return true;
}
