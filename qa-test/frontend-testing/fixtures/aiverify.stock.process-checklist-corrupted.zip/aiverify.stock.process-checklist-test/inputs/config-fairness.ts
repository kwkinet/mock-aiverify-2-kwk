export const config = {
  "principle": "Fairness",
  "description": "Fairness is about designing AI systems that avoid creating or reinforcing unfair bias in the AI system, based on the intended definition of fairness for individuals or groups, that is aligned with the desired outcomes of the AI system. The testable criteria focuses on testing the ability of the AI system to align with the intended fairness outcomes, throughout the AI lifecycle.",
  "sections": [
    {
      "section": "Fairness",
      "testType": "process-checklist",
      "checklist": [
        {
          "testableCriteria": "Put in place processes to test for potential biases during the entire lifecycle of the AI system, so that practitioners can act to mitigate biases based on feedback (e.g., biases due to possible limitations stemming from the composition of the used data sets such as a lack of diversity and non-representativeness.)",
          "processes": [
            {
              "pid": "fairness-4",
              "process": "Monitor the changes in fairness metric values in the lifecycle of the AI system.",
              "metric": "Physical testing",
              "processChecks": "Documentary evidence of implemented processes to test for potential biases during the entire lifecycle of the AI system."
            }
          ]
        },
        {
          "testableCriteria": "Establish a strategy for the selection of fairness metrics that are aligned with the desired outcomes of the AI system's intended application",
          "processes": [
            {
              "pid": "fairness-5",
              "process": "Consider using the fairness tree to select the fairness metrics- <a href=\"http://www.datasciencepublicpolicy.org/projects/aequitas/\" target=\"_blank\">http://www.datasciencepublicpolicy.org/projects/aequitas/</a>",
              "metric": "Internal procedure manual. For example: Binary classification<br/>- Equal Parity<br/>- Disparate Impact<br/>- False Negative Rate Parity<br/>- False Positive Rate Parity<br/>- False Omission Rate Parity<br/>- False Discovery Rate Parity<br/>- True Positive Rate Parity<br/>- True Negative Rate Parity<br/>- Negative Predictive Value Parity<br/>- Positive Predictive Value Parity<br/><br/>Regression<br/>- Bounded group loss",
              "processChecks": "Documentary evidence of strategy/process undertaken to select fairness metrics that align with the desired outcomes of the AI system's intended application."
            }
          ]
        },
        {
          "testableCriteria": "Define sensitive variables for the organisation that are consistent with the legislation and corporate values",
          "processes": [
            {
              "pid": "fairness-6-a",
              "process": "Identify the sensitive features and its privileged and unprivileged groups.",
              "metric": "Internal documentation. Examples of sensitive features could include religion, nationality, birth place, gender, race. Also refer to country-specific guidelines e.g. UK Equality Act",
              "processChecks": "Documentary evidence of identification of sensitive features and its privileged and unprivileged groups."
            },
            {
              "pid": "fairness-6-b",
              "process": "Where feasible, consult the impacted communities on the correct definition of fairness e.g. representatives of elderly persons or persons with disabilities.",
              "metric": "External / internal correspondence",
              "processChecks": "Documentary evidence of consultations conducted with impacted communities on the correct definition of fairness."
            }
          ]
        },
        {
          "testableCriteria": "Establish a process for identifying and selecting sub-populations between which the AI system should produce fair outcomes.",
          "processes": [
            {
              "pid": "fairness-7",
              "process": "Define this partitioning in terms of sensitive variables that models should be prohibited from being trained on, but are used in the evaluation of fairness outcomes.",
              "metric": "Physical testing",
              "processChecks": "Documentary evidence of establishment of a process for identifying and selecting sub-populations between which the AI system should produce fair outcomes"
            }
          ]
        },
        {
          "testableCriteria": "Establish a strategy or a set of procedures to check that the data used in the training of the AI model, is representative of the population who make up the end-users of the AI model.",
          "processes": [
            {
              "pid": "fairness-8",
              "process": "Perform exploratory data analysis. For the sensitive feature, test the representation of each group in the data. Resample data or collect more data if a particular group is severely underrepresented.",
              "metric": "Physical testing. Note: Sample proportions vs true population proportions for all groups",
              "processChecks": "Documentary evidence of establishment of a strategy or a set of procedures to check that the data used in the training of the AI model, is representative of the population who make up the end-users of the AI model."
            }
          ]
        },
        {
          "testableCriteria": "Put in place a mechanism that allows for the flagging of issues related to bias, discrimination or poor performance of the AI system",
          "processes": [
            {
              "pid": "fairness-9",
              "process": "Monitor threshold violations of fairness metrics.",
              "metric": "Physical testing",
              "processChecks": "Documentary evidence of monitoring of threshold violations of fairness metrics."
            }
          ]
        },
        {
          "testableCriteria": "Put in place appropriate mechanisms to ensure fairness in your AI system.",
          "processes": [
            {
              "pid": "fairness-10",
              "process": "Monitor metrics for the latest set of data for the model currently being deployed on an ongoing basis.",
              "metric": "Physical testing",
              "processChecks": "Documentary evidence of monitoring metrics for the latest set of data for the model currently being deployed on an ongoing basis."
            }
          ]
        },
        {
          "testableCriteria": "Address risk of biases due to possible limitations stemming from the composition of the used data sets (lack of diversity, non-representativeness), by applying appropriate adjustments on data samples of minorities.",
          "processes": [
            {
              "pid": "fairness-11",
              "process": "Where possible, handle imbalanced training sets with minorities. <br/>- Oversample minority class<br/>- Undersample majority class<br/>- Generate synthetic samples (SMOTE)",
              "metric": "Physical testing",
              "processChecks": "Documentary evidence of addressing risk of biases due to possible limitations stemming from the composition of the used data sets (lack of diversity, non-representativeness), by applying appropriate adjustments on data samples of minorities."
            }
          ]
        }
      ]
    }
  ],
  "summaryYes": "Company has put in place measures and processes to enable it to monitor, review and identify causes of model bias and address them accordingly.",
  "summaryNotYes": "By not implementing all the testable criteria, Company runs the risk of not being able to monitor and identify potential causes of bias and address them throughout the AI system’s lifecycle. This may result discriminatory outcomes for individuals affected by the AI system. This could also reduce overall trust in the system.",
  "recommendation": "It is recommended that Company implements all the testable criteria. Company should review the reasons for not implementing certain testable criteria and assess if these reasons are still valid."
}