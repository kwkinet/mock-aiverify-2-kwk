from tests.plugin_test import PluginTest

if __name__ == "__main__":

    data_path = "tests/user_defined_files/pickle_pandas_tabular_loan_testing.sav"
    model_path = "tests/user_defined_files/pickle_scikit_multiclasslr_loan.sav"
    ground_truth_path = ""
    ground_truth = ""

    plugin_argument_values = {
        "target_feature_name": "Interest_Rate",
        "percentiles": [0.05, 0.95],
        "grid_resolution": 100
    }

    # =====================================================================================
    # NOTE: Do not modify the code below
    # =====================================================================================
    # Perform Plugin Testing
    try:
        # Create an instance of PluginTest with defined paths and arguments and Run.
        plugin_test = PluginTest(
            data_path,
            model_path,
            ground_truth_path,
            ground_truth,
            plugin_argument_values
        )
        plugin_test.run()

    except Exception as exception:
        print(f"Exception caught while running the plugin test: {str(exception)}")
