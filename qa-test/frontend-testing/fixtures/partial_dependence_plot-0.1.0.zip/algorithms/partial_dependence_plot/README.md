# Algorithm - Partial Dependence Plot

## Description
* Partial dependence plot (PDP) depicts the relationship between a small number of input variable and target. They show how predictions partially depend on values of the input variables of interests.

## License
* Licensed under MIT

## Plugin URL
* https://gitlab.com/imda_dsl/t2po/ai-verify/ai-verify-stock-plugins/partial_dependence_plot

## Developers:
* Lionel Teo
